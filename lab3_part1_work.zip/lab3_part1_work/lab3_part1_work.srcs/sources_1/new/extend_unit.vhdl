library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

ENTITY extend_unit IS
    PORT (
        din  : IN STD_LOGIC_VECTOR(24 DOWNTO 0);
        ctrl : IN STD_LOGIC_VECTOR(2 DOWNTO 0);
        dout : OUT STD_LOGIC_VECTOR(31 DOWNTO 0)
    );
END extend_unit;

ARCHITECTURE Behavioral OF extend_unit IS    
    -- enumerated type for each instruction type 
    TYPE INST_TYPE_t is (R_TYPE, I_TYPE, S_TYPE, B_TYPE, U_TYPE, J_TYPE);

    -- helper function to zero-extend any STD_LOGIC_VECTOR to 32 bits
    -- append zeros to the right end (LSB) until the word reaches 32 bits
    FUNCTION zext(arg : STD_LOGIC_VECTOR; target_len : POSITIVE := 32) RETURN STD_LOGIC_VECTOR IS
        VARIABLE result : STD_LOGIC_VECTOR(target_len - 1 DOWNTO 0) := (OTHERS => '0');
    BEGIN
        -- MSBs become arg, LSBs remain '0'
        result(target_len - 1 DOWNTO target_len - arg'length) := arg;
        RETURN result;
    END FUNCTION;

    -- helper function to sign-extend any STD_LOGIC_VECTOR to 32 bits
    -- replicate the received MSB to the left end until the word reaches 32 bits.
    FUNCTION sgnext(arg : STD_LOGIC_VECTOR; target_len : POSITIVE := 32) RETURN STD_LOGIC_VECTOR IS
        VARIABLE result : STD_LOGIC_VECTOR(target_len - 1 DOWNTO 0) := (OTHERS => '0');
    BEGIN
        -- LSBs become arg
        result(arg'length - 1 DOWNTO 0) := arg;
        -- replicate MSB of arg (sign bit) to all upper bits of result
        result(target_len - 1 DOWNTO arg'length) := (OTHERS => arg(arg'left));
        RETURN result;
    END FUNCTION;
    
BEGIN
    WITH ctrl SELECT
                -- all zeros
        dout <= (OTHERS => '0') WHEN "000",
                -- zero-extend din(24:5)
                zext(din(24 DOWNTO 5)) WHEN "001",
                -- sign-extend din(24:13)
                sgnext(din(24 DOWNTO 13)) WHEN "010",
                -- zero-extend din(23) & din(17:13)
                zext(din(23) & din(17 DOWNTO 13)) WHEN "011",
                -- sign-extend din(24:18) & din(4:0)
                sgnext(din(24 DOWNTO 18) & DIN(4 DOWNTO 0)) WHEN "100",
                -- sign-extend din(24) & din(0) & din(23:18) & din(4:1) & '0'
                sgnext(din(24) & din(0) & din(23 DOWNTO 18) & din(4 DOWNTO 1) & '0') WHEN "101",
                -- sign-extend din(24) & din(12:5) & din(13) & din(23:14) & '0'
                sgnext(din(24) & din(12 DOWNTO 5) & DIN(13) & DIN(23 DOWNTO 14) & '0') WHEN "110",
                -- all ones
                (OTHERS => '1') WHEN OTHERS;
END Behavioral;