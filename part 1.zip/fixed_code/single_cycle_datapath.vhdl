------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410
-- Project     : Lab 3
-- File        : single_cycle_datapath.vhdl
-- Authors     : Antonio Alejandro Andara Lara
-- Date        : 23-Oct-2025
------------------------------------------------------------------------
-- Description  : Structural implementation of a single-cycle RISC-V datapath.
--                Includes PC, instruction fetch, decode, ALU, memory, and write-back.
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

ENTITY lw_sw_datapath IS
    PORT (
        clock       : IN  STD_LOGIC;
        Mem_we      : IN  STD_LOGIC;                  -- dp_13
        rd_we       : IN  STD_LOGIC;                  -- dp_10
        Alu_src     : IN  STD_LOGIC;                  -- dp_11
        Res_sel     : IN  STD_LOGIC;                  -- dp_14
        Out_en      : IN  STD_LOGIC;                  -- dp_15
        imm_sel     : IN  STD_LOGIC_VECTOR(2 DOWNTO 0); -- dp_8
        alu_ctrl    : IN  STD_LOGIC_VECTOR(2 DOWNTO 0); -- dp_12
        opcode      : OUT STD_LOGIC_VECTOR(6 DOWNTO 0); -- dp_1
        funct3      : OUT STD_LOGIC_VECTOR(2 DOWNTO 0); -- dp_2
        funct7_bit  : OUT STD_LOGIC;                  -- dp_3
        zero_flag   : OUT STD_LOGIC;
        out_data    : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
        pc_src      : IN std_logic 
    );
END ENTITY;

ARCHITECTURE structural OF lw_sw_datapath IS

    SIGNAL pc, pc_next                      : STD_LOGIC_VECTOR(31 DOWNTO 0) := (OTHERS => '0');
    SIGNAL instruction, imm_ext, alu_result : STD_LOGIC_VECTOR(31 DOWNTO 0) := (OTHERS => '0');
    SIGNAL rs1_data, rs2_data, rd_data       : STD_LOGIC_VECTOR(31 DOWNTO 0) := (OTHERS => '0');
    SIGNAL result_mux_o                      : STD_LOGIC_VECTOR(31 DOWNTO 0) := (OTHERS => '0');
    SIGNAL alu_mux_o                         : STD_LOGIC_VECTOR(31 DOWNTO 0) := (OTHERS => '0');
    SIGNAL pc_4   ,target_address            : std_logic_vector ; 

BEGIN
    opcode     <= instruction(6 DOWNTO 0);
    funct3     <= instruction(14 DOWNTO 12);
    funct7_bit <= instruction(30);

------------------------------------------------------------------------
-- FETCH BLOCK
------------------------------------------------------------------------
    dp_pc_adder : ENTITY work.adder_32(Behavioral)
        PORT MAP (
            op_a => pc,
            op_b => x"00000004",
            sum  => pc_next
        );

    dp_pc : ENTITY work.program_counter(Behavioral)
        PORT MAP (
            clock   => clock,
            pc_out  => pc,
            pc_next => pc_next
        );

    dp_instr_mem : ENTITY work.instr_mem(rtl)
        PORT MAP (
            address => pc,
            data    => instruction
        );
        
     dp_pc_src : ENTITY work.mux_2to1(Behavioral)
        PORT MAP (
            in0   => pc_4,
            in1   => target_address,
            out_y => pc_next,
            sel   => pc_src
        );
    dp_branch_adder : ENTITY work.adder_32(Behavioral)
        PORT MAP (
            op_a => pc,
            op_b => imm_ext,
            sum  => target_address
        );

    

------------------------------------------------------------------------
-- DECODE BLOCK
------------------------------------------------------------------------
    dp_regfile : ENTITY work.register_file(Behavioral)
        PORT MAP (
        
            clock    => clock,
            rs1_addr => instruction(19 DOWNTO 15),
            rs2_addr => instruction(24 DOWNTO 20),
            rd_addr  => instruction(11 DOWNTO 7),
            rd_data  => result_mux_o,
            rs1_data => rs1_data,
            rs2_data => rs2_data,
            rd_we    => rd_we
        );

    dp_extend : ENTITY work.extension_unit(Behavioral)
        PORT MAP (
            din  => instruction(31 DOWNTO 0),
            ctrl => imm_sel,
            dout => imm_ext
        );

------------------------------------------------------------------------
-- EXECUTE & MEMORY BLOCK
------------------------------------------------------------------------
    dp_alu_src : ENTITY work.mux_2to1(Behavioral)
        PORT MAP (
            in0   => rs2_data,
            in1   => imm_ext,
            out_y => alu_mux_o,
            sel   => Alu_src
        );

    dp_alu : ENTITY work.alu(Behavioral)
        PORT MAP (
            src_a     => rs1_data,
            src_b     => alu_mux_o,
            alu_ctrl  => alu_ctrl,
            result    => alu_result,
            zero_flag => zero_flag
        );

    dp_data_mem : ENTITY work.data_mem(rtl)
        PORT MAP (
            clock      => clock,
            address    => alu_result,
            write_data => rs2_data,
            data       => rd_data,
            write_en   => Mem_we
        );

------------------------------------------------------------------------
-- WRITE-BACK BLOCK
------------------------------------------------------------------------
    dp_result_src : ENTITY work.mux_2to1(Behavioral)
        PORT MAP (
            in0   => alu_result,
            in1   => rd_data,
            out_y => result_mux_o,
            sel   => Res_sel
        );

    dp_tri_state_buffer : ENTITY work.tri_state_buffer(Behavioral)
        PORT MAP (
            output_en     => Out_en,
            buffer_input  => result_mux_o,
            buffer_output => out_data
        );

END structural;